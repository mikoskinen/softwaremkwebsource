---
title: Getting Started Video
permalink: windows-phone-irc-client-irc7-getting-started
description: This help shows how to get started with IRC7.
layout: helppage.cshtml
tags: help, general
time: 2011-12-20 18:00
---
The [following video](http://www.youtube.com/watch?v=HmXZ-PKxQ68) shows how you can get started with this IRC chat app.