---
title: What IRC-networks are supported by the IRC client?
permalink: windows-phone-irc-client-irc7-irc-networks
description: IRC7 supports all the main networks like QuakeNet, IRCNet and Freenode.
layout: helppage.cshtml
tags: help, networks
time: 2011-12-28 18:00
---
IRC7 supports all the IRC-networks which follow the standard IRC-protocol. It has been tested with the following networks:

QuakeNet
IRCNet
Undernet
EFNet
DALnet
Freenode