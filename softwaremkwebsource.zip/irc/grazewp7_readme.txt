GrazeWP7

GrazeWP7 is a Windows Phone 7 app marketing site generator. It uses the Graze templating engine with Twitter Bootstrap. 

GrazeWP7 uses a simple configuration file to generate a static web site for your application. The generated site is pure HTML / CSS / JavaScript and can be hosted on any web server.

Project home: https://github.com/mikoskinen/grazewp7

*******************************

You have successfully installed GrazeWP7. 

To create your site with the Windows Phone 7 -template, run graze.exe from the root of your project.

To customize the site's content, edit the file "template\configurarion.xml".

To customize the site's layout, edit the contents of the folder "template".