### Kuinka kiinnitän suosikkijoukkueeni puhelimen käynnistysvalikkoon? ###
Kiinnitä-toiminto löytyy, kun ensin navigoit haluamasi joukkueen tietoihin ja valitset toimintovalikosta kiinnitä. 

### Puhelimen asetuksista näkee, että sovelluksella on tausta-agentti. Mitä se tekee? ###
SuomiFutis-sovelluksen tausta-agentti päivittää käynnistysvalikkoon kiinnitettyyn tiileen päivän ottelut sekä uusimman uutisen.