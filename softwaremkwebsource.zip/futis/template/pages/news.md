### Ensimmäinen julkaisu: SuomiFutis Windows Phone -sovellus. Seuraa suomalaista jalkapalloa Windows puhelimellasi. ###
###### 15.4.2012 ######
SuomiFutis on uusi Windows Phone -sovellus suomalaisen jalkapallon seurantaan. Voit seurata sen avulla pääsarjan joukkueita, otteluita ja uutisia. 

Poimintoja ominaisuuksista:
* Ottelut
* Tilastot
* Uutiset
* Live-tiili näyttää päivän ottelut ja viimeisimmät uutiset
* Joukkuekohtainen tiili kertoo seuraavan ottelun ajankohdan
* Jaa tulokset kavereidesi kanssa