Graze

Graze is a static site generator. It takes a template and a configuration file and generates a static web site. 
The generated site is pure HTML / CSS / JavaScript and can be hosted on any web server. The Graze templates are created using the Razor Syntax.

Project home: https://github.com/mikoskinen/graze

*******************************

You have successfully installed Graze. 

To create your site with the default template, run graze.exe from the root of your project.

To customize the site's content, edit the file "template\configurarion.xml".

To customize the site's layout, edit the contents of the folder "template".