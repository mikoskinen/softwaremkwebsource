### Miksi suosituimmat uutiset eivät ole helposti luettavissa? ###
Ampparit-lukija on epävirallinen Ampparit.com -sovellus. Ampparit-lukija hyödyntää Ampparit.comin tarjoamia avoimia uutislähteitä, mutta valitettavasti suosituimmat uutiset eivät ole saatavilla näiden avoimien lähteiden kautta.

### Miten live-tiilet saa käyttöön? ###
Lisää ensin haluamasi uutisalue suosikiksi. Tämän jälkeen etusivun suosikit-näkymässä paina haluamasi suosikki hetkeksi pohjaan, jonka jälkeen aukeavasta kontekstivalikosta voit kiinnittää live-tiilen käynnistysvalikkoon.

### Kuinka vaihdan lennosta uutisten ryhmittelyn kellonajasta uutislähteeseen? ###
Ryhmittelyn vaihtamisen voi tehdä pysyvästi asetusten kautta, tai vaihtoehtoisesti pinch-liikkeellä.