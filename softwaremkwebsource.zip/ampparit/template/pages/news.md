### 2.8 versio saatavilla ###
###### 13.5.2012 ######

Uusi versio Ampparit.com -lukijasta on saatavilla. Uutta tässä versiossa:

* Sovelluksen käynnistystiileen lisätty suosikeista tutut live-tiili ominaisuudet
* Hieman kevenetty värimaailma
* Lukittu sovellus portrait-moodiin
* Pieniä parannuksia mobiililukutilaan
* Pinch-liikkeellä tapahtuva uutisten ryhmittely otettu toistaiseksi pois käytöstä. Ominaisuus aiheuttaa joillain puhelinmalleilla kaatuilua.

### 2.7 versio pian saatavilla ###
###### 20.3.2012 ######
Windows Phonen markkinapaikalta on pian ladattavissa Ampparit.com Reader -sovelluksen versio 2.7. 

Uutta versiossa:
* Pieniä parannuksia mobiililukutilaan.

### 2.6 versio saatavilla ###
###### 10.3.2012 ######
Tämä versio tuo mukanaan kokonaan uuden lukukokemuksen. Sen lisäksi, että uutiset aukeavat huomattavasti nopeammin, voit myös valita kerralla useita uutisia luettavaksi. Lisäksi uutiset muotoillaan paremmin kännykän näytölle sopivaksi.
